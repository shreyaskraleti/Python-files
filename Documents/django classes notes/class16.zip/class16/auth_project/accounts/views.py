from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from .forms import UserRegisterForm
from .models import Profile

# Create your views here.

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            Profile.objects.create(user=user)
            login(request, user)
            return redirect('profile')
    else:
        form = UserRegisterForm()
    return render(request, 'accounts/register.html', {'form':form})

@login_required
def profile(request):
    return render(request, 'accounts/profile.html')

@login_required
def user_logout(request):
    logout(request)
    return redirect('login')  # Redirect to login after logout

@login_required
def home(request):
    return render(request, 'accounts/home.html')


@login_required
def dashboard_view(request):
    is_editor = request.user.groups.filter(name='Editor').exists()
    is_reader = request.user.groups.filter(name='Reader').exists()
    
    return render(request, 'accounts/dashboard.html', {
        'is_editor': is_editor,
        'is_reader': is_reader
    })