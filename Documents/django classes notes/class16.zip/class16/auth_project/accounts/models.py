
from django.db import models
from django.contrib.auth.models import User

# Extending the User model with a Profile
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    is_premium = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username

# Optionally: Group-based permissions (for example, 'Editors' and 'Readers')
from django.contrib.auth.models import Group, Permission

def create_default_groups():
    # Create Groups
    editors_group, created = Group.objects.get_or_create(name='Editors')
    readers_group, created = Group.objects.get_or_create(name='Readers')

    # Define Permissions for Editors and Readers
    edit_permission = Permission.objects.get(codename='change_article')
    view_permission = Permission.objects.get(codename='view_article')

    # Assign permissions to groups
    editors_group.permissions.add(edit_permission, view_permission)
    readers_group.permissions.add(view_permission)
