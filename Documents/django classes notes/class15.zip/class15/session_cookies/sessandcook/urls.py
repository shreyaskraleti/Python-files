from django.urls import path
from .views import set_name, get_name, delete_cookie, set_expiry_date, delete_expiry_date, delete_session

urlpatterns = [
    path('set_name/', set_name, name='set_name'),
    path('get_name/', get_name, name='get_name'),
    path('delete_cookie/', delete_cookie, name='delete_cookie'),
    path('set_expiry_date/', set_expiry_date, name='set_expiry_date'),
    path('delete_expiry_date/', delete_expiry_date, name='delete_expiry_date'),
    path('delete_session/', delete_session, name='delete_session'),
]
