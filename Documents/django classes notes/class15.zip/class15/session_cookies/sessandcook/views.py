from django.shortcuts import render
from django.http import HttpResponse
from .forms import NameForm
# Create your views here.

def set_name(request):
    if request.method == 'POST':
        form = NameForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            request.session['username'] = name
            response = HttpResponse("Name set successfully")
            response.set_cookie('username', name)
            if request.session.test_cookie_worked():
                request.session.delete_test_cookie()
            return response
    else:
        form = NameForm()
    return render(request, 'set_name.html', {'form':form})

def get_name(request):
    username_from_session = request.session.get('username')
    username_from_cookie = request.COOKIES.get('username')
    expiry_date = request.session.get_expiry_date()

    return render(request, 'get_name.html', 
                {'username_from_session':username_from_session, 
                 'username_from_cookie':username_from_cookie, 
                 'expiry_date':expiry_date})

def delete_cookie(request):
    response = HttpResponse("Cookie deleted successfully")
    response.delete_cookie('username')
    return response

def set_expiry_date(request):
    request.session.set_expiry(3600)
    return HttpResponse('Session expiry date set successfully!')

def delete_expiry_date(request):
    request.session.set_expiry(0)
    return HttpResponse('Session expiry date deleted successfully!')

def delete_session(request):
    request.session.flush()
    return HttpResponse('Session deleted successfully!')


