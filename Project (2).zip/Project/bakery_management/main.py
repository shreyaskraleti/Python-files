import mysql.connector
def main():
    try:
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="shreya93@",
            database="bakery_management"
        )
        print("Connected to the database successfully.")
    except mysql.connector.Error as err:
        print(f"Error connecting to the database: {err}")
        return

    auth = Auth(db)
    items = BakeryItem(db)
    reports = Reports(db)

    user_role = None
    while True:
        print("\n--- Bakery Management ---")
        print("1. Register")
        print("2. Login")
        print("3. Add Item (Manager only)")
        print("4. Update Stock")
        print("5. Generate Sales Report")
        print("6. Display Inventory")
        print("7. Exit")

        choice = input("Select an option: ")

        if choice == '1':
            username = input("Username: ")
            password = input("Password: ")
            role = input("Role (cashier/manager): ").lower()
            if role in ['cashier', 'manager']:
                auth.register(username, password, role)
                print("Registration successful.")
            else:
                print("Invalid role. Please enter either 'cashier' or 'manager'.")

        elif choice == '2':
            username = input("Username: ")
            password = input("Password: ")
            user_role = auth.login(username, password)
            if user_role:
                print(f"Login successful! You are logged in as a {user_role}.")
            else:
                print("Login failed. Please check your credentials.")

        elif choice == '3':
            if user_role == 'manager':
                try:
                    name = input("Item Name: ")
                    price = float(input("Item Price: "))
                    stock = int(input("Item Stock: "))
                    items.add_to_db(name, price, stock)
                except ValueError:
                    print("Invalid input for price or stock. Please enter valid numbers.")
            else:
                print("Access Denied: Only managers can add items.")

        elif choice == '4':
            if user_role:
                try:
                    item_name = input("Item Name: ")
                    quantity_sold = int(input("Quantity Sold: "))
                    items.update_stock(item_name, quantity_sold)
                except ValueError:
                    print("Invalid quantity. Please enter a valid number.")
            else:
                print("You must be logged in to update stock.")

        elif choice == '5':
            if user_role:
                period = input("Enter report period (daily/weekly/monthly): ").lower()
                if period in ['daily', 'weekly', 'monthly']:
                    reports.generate_report(period)
                else:
                    print("Invalid period. Please choose 'daily', 'weekly', or 'monthly'.")
            else:
                print("You must be logged in to generate a report.")

        elif choice == '6':
            if user_role:
                items.display_inventory()
            else:
                print("You must be logged in to view inventory.")

        elif choice == '7':
            print("Exiting system. Goodbye!")
            db.close()
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
